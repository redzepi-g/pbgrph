$(document).ready(function(){
    alert("Edoni in the house.");
});